# Initialize webcam
import cv2
cap = cv2.VideoCapture(0)  # Change index if needed for different camera

# Set preferred resolution
preferred_width = 1280
preferred_height = 720
cap.set(3, preferred_width)  # Set width
cap.set(4, preferred_height)  # Set height

# Check if the resolution is supported
actual_width = cap.get(3)
actual_height = cap.get(4)
print(f"Using Resolution: {int(actual_width)}x{int(actual_height)}")

# Continue with your application logic...
