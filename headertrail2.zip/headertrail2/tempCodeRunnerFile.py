import cv2
import os
import HandTrackingModule as htm
import numpy as np

# Brush and eraser thickness
brushThickness = 15
eraserThickness = 100
actions = []

# Folder paths for header and right panel images
header_folder_path = "C:\\Users\\dell\\Downloads\\minor\\headertrail2"
right_panel_folder_path = "C:\\Users\\dell\\Downloads\\minor\\headertrail2\\newfolder"

# Loading header images
header_images = [cv2.imread(f'{header_folder_path}/{file}') for file in os.listdir(header_folder_path)]
header_images = [img for img in header_images if img is not None]

# Loading right panel images
right_panel_images = [cv2.imread(f'{right_panel_folder_path}/{file}') for file in os.listdir(right_panel_folder_path)]
right_panel_images = [img for img in right_panel_images if img is not None]

# Validate loaded images
if not header_images:
    print("No header images found.")
    exit()
if not right_panel_images:
    print("No right panel images found.")
    exit()

# Initialize header and right panel
header = header_images[0]
right_panel = right_panel_images[0]

# Default color and mode
drawColor = (0, 0, 255)  # Red for drawing
mode = "Drawing"  # Initial mode

# Webcam setup
cap = cv2.VideoCapture(0)
cap.set(3, 1280)  # Width
cap.set(4, 720)   # Height
detector = htm.handDetector(detectionCon=0.80)
xp, yp = 0, 0
imgCanvas = np.zeros((720, 1280, 3), np.uint8)
smoothening = 5

def undo():
    global actions
    if actions:
        actions.pop()

def redo():
    global actions
    if actions:
        actions.append(actions[-1])

def clear():
    global imgCanvas, actions
    imgCanvas = np.zeros((720, 1280, 3), np.uint8)
    actions.clear()

while True:
    success, img = cap.read()
    if not success:
        break

    img = cv2.flip(img, 1)  # Mirror the camera feed
    img = detector.findHands(img)
    lmList = detector.findPosition(img, draw=False)

    if lmList:
        x1, y1 = lmList[8][1:]  # Index finger tip
        x2, y2 = lmList[12][1:]  # Middle finger tip
        fingers = detector.fingerUp()
        print(fingers)  # Debugging the finger states

        # Check if both index and middle fingers are up for selection mode
        if fingers[1] == 1 and fingers[2] == 1:  # Both index and middle fingers up
            mode = "Selection"
            xp, yp = 0, 0  # Reset drawing points when selecting color
            print("Selection Mode")

            # Header selection (top area)
            if y1 < 125:
                if 170 < x1 < 271:
                    header = header_images[0]
                    drawColor = (0, 0, 255)  # Red
                elif 294 < x1 < 380:
                    header = header_images[1]
                    drawColor = (0, 165, 255)  # Orange
                elif 411 < x1 < 498:
                    header = header_images[2]
                    drawColor = (255, 100, 1)  # Blue
                elif 530 < x1 < 616:
                    header = header_images[3]
                    drawColor = (128, 0, 128)  # Purple
                elif 661 < x1 < 745:
                    header = header_images[4]
                    drawColor = (160, 32, 240)  # Pink
                elif 787 < x1 < 860:
                    header = header_images[5]
                    drawColor = (34, 139, 34)  # Dark Green
                elif 916 < x1 < 1000:
                    header = header_images[6]
                    drawColor = (173, 216, 230)  # Cream
                elif 1044 < x1 < 1127:
                    header = header_images[7]
                    drawColor = (0, 255, 255)  # Yellow
                elif 1130 < x1 < 1227:
                    header = header_images[8]
                    drawColor = (0, 255, 0)  # Green

            # Right panel selection (buttons for Eraser, Undo, Redo, Clear)
            if x1 > 980:  # Right panel starts at x=980
                  if 26 < y1 < 85:  # Brush size: 10
                      brushSize = 10
                      print("Brush Size set to 10")
                  elif 86 < y1 < 148:  # Brush size: 15
                      brushSize = 15
                      print("Brush Size set to 15")
                  elif 151 < y1 < 221:  # Brush size: 20
                      brushSize = 20
                      print("Brush Size set to 20")
                  elif 230 < y1 < 300:  # Undo button
                      undo()
                      print("Undo Action")
                  elif 309 < y1 < 382:  # Redo button
                      redo()
                      print("Redo Action")
                  elif 398 < y1 < 462:  # Eraser button
                      drawColor = (0, 0, 0)  # Set color to black for eraser
                      print("Eraser Mode")
                  elif 466 < y1 < 538:  # Clear all button
                      clear()
                      print("Clear Canvas")

    

        # Drawing Mode (only index finger up)
        elif fingers[1] == 1 and fingers[2] == 0:  # Only index finger up
            mode = "Drawing"
            print("Drawing Mode")
            cv2.circle(img, (x1, y1), 15, drawColor, cv2.FILLED)

            # Start drawing
            if xp == 0 and yp == 0:
                xp, yp = x1, y1

            # Apply smoothing effect
            x1 = int(xp + (x1 - xp) / smoothening)
            y1 = int(yp + (y1 - yp) / smoothening)

            # Erase if the color is black
            if drawColor == (0, 0, 0):
                cv2.line(img, (xp, yp), (x1, y1), drawColor, eraserThickness)
                cv2.line(imgCanvas, (xp, yp), (x1, y1), drawColor, eraserThickness)
            else:
                cv2.line(img, (xp, yp), (x1, y1), drawColor, brushThickness)
                cv2.line(imgCanvas, (xp, yp), (x1, y1), drawColor, brushThickness)

            xp, yp = x1, y1  # Update previous points

    # Combine canvas with original feed
    imgGray = cv2.cvtColor(imgCanvas, cv2.COLOR_BGR2GRAY)
    _, imgInv = cv2.threshold(imgGray, 50, 255, cv2.THRESH_BINARY_INV)
    imgInv = cv2.cvtColor(imgInv, cv2.COLOR_GRAY2BGR)

    img = cv2.bitwise_and(img, imgInv)
    img = cv2.bitwise_or(img, imgCanvas)

    # Overlay the header
    img[0:125, 0:1280] = header
    # Resize the right panel to fit the full height and adjust the width to 150px
    right_panel_resized = cv2.resize(right_panel, (150, 595))  # Resize the right panel to a width of 150px and height of 595px

# Place the resized right panel starting from 125px from the top (below the header)
    img[125:720, 1130:1280] = right_panel_resized  # Adjusted the x-range for the resized panel to fit the full right side

     
    # Show final image
    cv2.imshow("Image with Overlay", img)
    cv2.imshow("Canvas", imgCanvas)

    # Break loop on 'q' key
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
